# Group3-Pratice
this is a Repo for Group 3 Practice in Class 2.
Group Members Are:
James Filip,
Jesse Caddell,
Sarah Bright,
Nickolas Ramirez
